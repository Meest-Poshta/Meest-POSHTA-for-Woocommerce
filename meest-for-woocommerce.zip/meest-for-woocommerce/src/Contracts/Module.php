<?php

namespace MeestShipping\Contracts;

interface Module
{
    public function init();
}
