<?php
namespace MeestShipping\Resources;

use MeestShipping\Core\Resource;

class ParcelApiResource extends Resource
{
    public function toArray(): array
    {
        $places = $this->getPlaces();

        return [
            'COD' => $this->options['shipping']['auto_cod'] == 1 ? $this->data['parcel']['cod'] : null,
            'payType' => $this->data['parcel']['pay_type'] == 1 ? 'cash' : 'noncash',
            'receiverPay' => (bool) $this->data['parcel']['payer'],
            'notation' => $this->data['parcel']['notation'],
            'sender' => array_merge(
                $this->getUser($this->data, 'sender'),
                $this->getAddress($this->data, 'sender')
            ),
            'receiver' => array_merge(
                $this->getUser($this->data, 'receiver'),
                $this->getAddress($this->data, 'receiver')
            ),
            'placesItems' => $places,
            /*'contentsItems' => array_map(static function ($item) {
                return [
                    'contentName' => $item['contentName'],
                    'quantity' => $item['quantity'],
                    'weight' => $item['weight'] ?: null,
                    'value' => $item['value'],
                ];
            }, $items),*/
        ];
    }

    private function getUser($data, $type): array
    {
        return [
            'name' => $data[$type]['last_name'].' '.$data[$type]['first_name']
                .($data[$type]['middle_name'] ? ' '.$data[$type]['middle_name'] : null),
            'phone' => $data[$type]['phone']
        ];
    }

    private function getAddress($data, $type): array
    {
        $arr = [
            'countryId' => $data[$type]['country']['id']
        ];

        if ($data[$type]['delivery_type'] === 'branch') {
            $arr['service'] = 'Branch';
            $arr['branchId'] = $data[$type]['branch']['id'];
        } elseif ($data[$type]['delivery_type'] === 'poshtomat') {
            // Поштомат обрабатывается как Branch
            $arr['service'] = 'Branch';
            $arr['branchId'] = $data[$type]['poshtomat']['id'];
        } else {
            // Курьерская доставка (address)
            $arr['service'] = 'Door';
            if ($data[$type]['country']['id'] === $this->options['country_id']['ua']) {
                $arr['cityId'] = $data[$type]['city']['id'];
                $arr['addressId'] = $data[$type]['street']['id'];
            } else {
                $arr['regionDescr'] = $data[$type]['region']['text'];
                $arr['cityDescr'] = $data[$type]['city']['text'];
                $arr['addressDescr'] = $data[$type]['street']['text'];
            }
            $arr['building'] = $data[$type]['building'];
            $arr['flat'] = $data[$type]['flat'];
        }

        return $arr;
    }

    private function getPlaces(): array
    {
        $arr[] = [
            'quantity' => 1,
            'insurance' => $this->data['parcel']['insurance'],
            'weight' => $this->data['parcel']['weight'],
            'pack_type' => $this->data['parcel']['pack_type'],
            'length' => $this->data['parcel']['lwh'][0],
            'width' => $this->data['parcel']['lwh'][1],
            'height' => $this->data['parcel']['lwh'][2],
            //'placeVolume' => 0,
        ];

        return $arr;
    }
}
