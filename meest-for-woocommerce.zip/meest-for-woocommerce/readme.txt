=== Meest for WooCommerce ===
Contributors: deveu
Tags: meest, commerce, woocommerce, shop, post, delivery, shipping, meest-express, meest-post, courier, delivery, міст, міст-експрес, пошта, мист, мист-экспресс, почта, доставка
Requires at least: 4.1
Tested up to: 6.4
Requires PHP: 7.0
Stable tag: 1.4.5
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Плагін Meest ПОШТА для WooCommerce забезпечує швидку та глибоку інтеграцію сервісів доставки Meest у ваш інтернет-магазин на WordPress.

== Description ==

Він додає інтерактивну карту відділень прямо на сторінку оформлення замовлення, автоматично розраховує вартість доставки через API, дозволяє створювати експрес-накладні у панелі керування та повністю автоматизує логістику.
Це ідеальне рішення для магазинів будь-якого масштабу, що прагнуть підвищити зручність оформлення замовлень і зменшити час обробки відправлень.

Переваги плагіна

**🗺️ 1. Інтерактивна карта відділень Meest на сторінці оформлення замовлення**

Плагін додає повноцінну мапу з усіма доступними відділеннями та поштоматами.

Ключові можливості:

*покупець бачить усі точки видачі у своєму місті,
*може натиснути на будь-яке відділення на карті,
*дані автоматично підтягуються у поля доставки (адреса, індекс, номер відділення),
*мінімізуються помилки при введенні інформації.

Це суттєво підвищує конверсію сторінки оформлення замовлення завдяки простому та зрозумілому вибору відділення.

**🚀 2. Зручний і швидкий вибір відділень у випадаючому списку**

Окрім карти, доступний також:

*розумний випадаючий список відділень,
*автопошук та автопідказки,
*миттєве оновлення даних по місту, району чи індексу,
*повна підтримка мобільних пристроїв.

Користувач легко знаходить потрібне відділення за назвою або номером.

**⚡ 3. Миттєвий розрахунок вартості доставки через API**

Плагін отримує точну вартість доставки безпосередньо з API Meest ПОШТА.

Розрахунок враховує:

*вагу товарів,
*габарити,
*маршрут доставки,
*актуальні тарифи,
*можливість контрактної доставки (ідентифікатор договору).

Сума доставки відображається автоматично та завжди відповідає актуальним тарифам.

**📦 4. Створення та керування накладними з панелі керування WooCommerce**

У панелі керування ви можете:

*створювати експрес-накладні в один клік зі сторінки замовлення,
*редагувати параметри доставки,
*передавати накладну в Meest без використання зовнішнього особистого кабінету,
*автоматично отримувати трек-номер.

Це значно прискорює обробку замовлень і зменшує кількість помилок.

**🔍 5. Відстеження статусів відправлень у реальному часі**

Плагін дозволяє відстежувати:

*поточний статус доставки,
*етапи доставки,
*дату і час змін статусу,
*інформацію по кожному трек-номеру.

Менеджеру не потрібно витрачати час на ручну перевірку.

**🖨️ 6. Друк супровідних документів**

Прямо з WooCommerce можна друкувати:

*експрес накладні
*транспортні накладні,
*реєстри відправленьі.

І все це формується автоматично.

**Додаткові можливості плагіна**

*Підтримка WooCommerce 5.x – 8.x
*Сумісність з більшістю шаблонів (Astra, OceanWP, Woodmart, Storefront тощо)
*Робота з популярними плагінами для оформлення замовлення (CheckoutWC, CartFlows, Fluid Checkout)
*Налаштування безкоштовної доставки від певної суми
*Гнучка система тарифів
*Повна підтримка ідентифікатора договору (Contract ID)
*Робота без модифікацій ядра WordPress
*Легке встановлення та інтуїтивні налаштування

**Чому магазини обирають Meest ПОШТА для WooCommerce?**

*Максимально простий і сучасний досвід користувача (UX) для покупця.
*Інтерактивна карта значно підвищує конверсію на сторінці оформлення замовлення.
*Точний розрахунок доставки з API без ручних тарифів.
*Повна автоматизація логістики.
*Економія часу менеджерів магазину.
*Мінімум налаштувань — максимум функціоналу.

Це найкомфортніший спосіб додати доставку Meest до WooCommerce, отримуючи професійний і стабільний інструмент для щоденної роботи


== Встановлення ==

1. Завантажте файли плагіна в каталог `/wp-content/plugins/meest-for-woocommerce` або встановіть плагін безпосередньо через екран плагінів WordPress.
2. Активуйте плагін через екран «Плагіни» в WordPress.
3. Використовуйте екран WooCommerce->Meest Settings для налаштування плагіна.
4. Введіть свої облікові дані Meest API.
5. Налаштуйте інформацію про відправника та параметри доставки.

== Поширені запитання ==

= Як отримати облікові дані API Meest? =

Вам потрібно зв'язатися з Meest і зареєструвати обліковий запис API. Відвідайте https://meest.com для отримання додаткової інформації.

= Які версії WooCommerce підтримуються? =

Плагін сумісний з WooCommerce 3.6.4 і вище, протестований до WooCommerce 9.0.0.

= Чи можу я використовувати цей плагін для міжнародних доставок? =

Так, плагін підтримує як українські, так і міжнародні доставки. Для України ви можете використовувати доставку до відділення, поштомата або за адресою. Для інших країн доступна доставка за адресою.

= Як створити посилку з замовлення? =

При перегляді замовлення WooCommerce з обраною доставкою Meest ви побачите кнопку «Створити посилку». Натисніть її, щоб автоматично створити посилку з інформацією про замовлення.

= Чи можу я відстежувати посилки? =

Так, ви можете відстежувати посилки безпосередньо з інтерфейсу плагіна, а номери для відстеження автоматично надсилаються клієнтам електронною поштою.

== Screenshots ==

1. Plugin settings page - API configuration
2. General settings - sender information
3. Cost calculation settings
4. Parcel list view
5. Parcel creation form
6. Pickup management
7. Order integration - create parcel button

== Changelog ==

= 1.4.5 =
* Fixed: Final fix for display fields

= 1.4.1 =
* Fixed: Added Ukrainian language support for all settings fields

= 1.4.0 =
* Fixed: City search functionality corrections
* Fixed: Checkout error when selecting parcel lockers
* Feature: Added support for custom street name input

= 1.3.2 =
* Fixed: Resolved issue with lost branches/departments during synchronization
* Improved: Branch data validation and import reliability

= 1.3.1 =
* Fixed: Resolved issue with missing cities during import process
* Improved: City data integrity during database synchronization

= 1.3.0 =
* Added Flatpickr date picker plugin for better UX
* Added email templates for parcel notifications
* Added comprehensive language support (Russian and Ukrainian translations)
* Added pickup management features (form and list views)
* Added parcel tracking functionality
* Added new about page and support sections
* Improved settings pages structure (API, Cost, General)
* Enhanced REST API functionality
* Added multiple repository classes for better data management
* Improved error handling with custom exceptions
* Added migration system for database updates
* Performance improvements and code optimization

= 1.2.1 =
* Added search for branches in the drop-down list.

= 1.2.0 =
* Added auto-fill of delivery fields when creating a consignment note.
* Fixed a module delivery display error for the standard checkout.
* Errors with loading delivery departments have been fixed.
* Fixed: Removed unsafe header() calls from main plugin file

= 1.1.0 =
* Security: Fixed SQL injection vulnerability in ParcelRepository
* Security: Added proper output escaping in view templates
* Security: Improved uninstall.php security checks
* Fixed: Removed unsafe header() calls from main plugin file
* Fixed: Updated text domain to use dashes instead of underscores
* Fixed: Removed CDN dependencies, all assets now bundled locally
* Improved: Better CSRF protection with nonce verification
* Improved: Updated WooCommerce compatibility to 9.0.0
* Improved: Code standards compliance improvements

= 1.0.5 =
* Add authorization by token
* Add address dictionary by DB
* Fix bugs

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.3.0 =
Major update with new features: Flatpickr integration, email templates, multilingual support, pickup management, parcel tracking, and enhanced REST API. Recommended update for all users.

= 1.2.1 =
Important security update. Please update immediately. This version fixes SQL injection vulnerabilities and improves overall security.
